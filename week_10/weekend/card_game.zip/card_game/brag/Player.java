package brag;

public class Player {

  public String name;
  // public ArrayList<Card> hand;

  public Player(String name){
  this.name = name;

}

}